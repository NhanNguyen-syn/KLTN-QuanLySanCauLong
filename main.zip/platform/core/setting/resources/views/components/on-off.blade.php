<x-core::form.on-off {{ $attributes }} />
