<x-core-setting::section.action.save :form="$form">
    @yield('content')
</x-core-setting::section.action.save>
