<x-core::icon name="ti ti-plus" />{{ trans('core/base::forms.create') }}
