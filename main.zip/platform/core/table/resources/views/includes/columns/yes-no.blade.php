<x-core::badge :label="$value ? trans('core/base::base.yes') : trans('core/base::base.no')" :color="$value ? 'success' : 'danger'" />
