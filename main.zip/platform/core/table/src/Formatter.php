<?php

namespace Botble\Table;

use Yajra\DataTables\Contracts\Formatter as BaseFormatter;

interface Formatter extends BaseFormatter
{
}
